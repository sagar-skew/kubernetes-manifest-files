# AK8S - Kubernetes Engine Samples
This repository contains sample applications used in introductory Kubernetes labs FOR
[Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine/).

See the following resources to learn more:

- [Google Kubernetes Engine - Quickstart](https://cloud.google.com/kubernetes-engine/docs/quickstart)
