# Architecting with Google Kubernetes Engine

These labs provide hands on exercises for the Architecting with Google Kubernetes Engine course. 