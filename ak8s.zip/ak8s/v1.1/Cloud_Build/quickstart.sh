#!/bin/sh
echo "Hello, world! The time is $(date)."
